
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DATA TABLE</title>
    <!--CSS-->    
    <!--<link rel="stylesheet" href="media/css/bootstrap.css">
    <link rel="stylesheet" href="media/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="media/font-awesome/css/font-awesome.css">-->
    <!--Javascript-->    
    <!--<script src="media/js/jquery-1.10.2.js"></script>
    <script src="media/js/jquery.dataTables.min.js"></script>
    <script src="media/js/dataTables.bootstrap.min.js"></script>          
    <script src="media/js/bootstrap.js"></script>
    <script src="media/js/app.js"></script>    --> 
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.css">

    <link rel="stylesheet" type="text/css" href="dataTable/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="#dataTable/dataTables.bootstrap.min.css">

    <script type="text/javascript" src="jquery/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <script type="text/javascript" src="dataTable/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="dataTable/dataTables.bootstrap.min.js"></script>

    <script type="text/javascript" src="js/app.js"></script>
  
</head>

<body>
<div class="col-md-8 col-md-offset-2">
    <div class="messages_del"></div>
    <h1>DATA TABLE
        <a href="#" class="btn btn-success  pull-right menu" data-toggle="modal" data-target="#addDato" id="adddatos"><i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp;Nuevo Registro</a>
    </h1> 

</div>
<div class="col-md-8 col-md-offset-2">    
    <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%" >
        <thead>
        <tr>
            <th>#</th>
            <th>Campo1</th>
            <th>Campo2</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tbody>
        </tbody>
        <tfoot>
        <tr>
            <th>#</th>
            <th>Campo1</th>
            <th>Campo2</th>
            <th>Acciones</th>
        </tr>
        </tfoot>
    </table>        
</div>

<!-- add modal -->
    <div class="modal fade" tabindex="-1" role="dialog" id="addDato">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"><span class="glyphicon glyphicon-plus-sign"></span> Agregar Registro</h4>
          </div>
          
          <form class="form-horizontal" method="POST" id="createdata"  autocomplete="off">

          <div class="modal-body">
              <div class="messages_add"></div>

              <div class="form-group"> 
                <label for="campo1" class="col-sm-2 control-label">Campo1</label>
                <div class="col-sm-10"> 
                  <input type="text" class="form-control" id="i_camp1" name="i_camp1" placeholder="Campo 1" required>                
                </div>
              </div>

              <div class="form-group">
                <label for="campo2" class="col-sm-2 control-label">Campo2</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="i_camp2" name="i_camp2" placeholder="Campo 2" required>
                </div>
              </div>           

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            <button type="submit" class="btn btn-success">Guardar datos</button>
          </div>
          </form> 
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- /add modal -->

    <!-- add modal -->
    <div class="modal fade" tabindex="-1" role="dialog" id="myUpd">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"><span class="glyphicon glyphicon-plus-sign"></span> Actualizar Registro</h4>
          </div>
          
          <form class="form-horizontal" method="POST" id="upddata"  autocomplete="off">

          <div class="modal-body">
              <div class="messages_upd"></div>

              <div class="form-group"> 
                <label for="usuario" class="col-sm-2 control-label">Campo1</label>
                <div class="col-sm-10"> 
                  <input type="text" class="form-control" id="a_camp1" name="a_camp1" placeholder="Campo 1" required> 
                  <input type="hidden" name="a_id" id="a_id" class="form-control">               
                </div>
              </div>

              <div class="form-group">
                <label for="password" class="col-sm-2 control-label">Campo2</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="a_camp2" name="a_camp2" placeholder="Campo 2" required>
                </div>
              </div>           

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            <button type="submit" class="btn btn-primary">Actualizar datos</button>
          </div>
          </form> 
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- /add modal -->

      <!-- add modal -->
    <div class="modal fade" tabindex="-1" role="dialog" id="myDel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"><span class="glyphicon glyphicon-plus-sign"></span> Remover Registro</h4>
          </div>
          
          <form class="form-horizontal" method="POST" id="deldata"  autocomplete="off">

          <div class="modal-body">

              <div class="form-group"> 
                <div class="col-lg-1"></div>
                <div class="col-lg-10">
                  <h4>¿Al dar Eliminar, Se Eliminaran los datos de Forma Permanente?</h4>
                  <input type="hidden" name="e_id" id="e_id" class="form-control">
                </div> 
                <div class="col-lg-1"></div>               
              </div>                 

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            <button type="submit" class="btn btn-danger">Eliminar</button>
          </div>
          </form> 
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- /add modal -->
</body>
</html>
