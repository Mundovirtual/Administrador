<?php

require_once 'dbconfig.php';


if(isset($_POST)) {
	if (empty($_POST['a_id'])) {
		$errors[] = "El id esta Vacío";
	}else if (empty($_POST['a_camp1'])) {
		$errors[] = "Campo 1 esta Vacío";
	}else if (empty($_POST['a_camp2'])) {
		$errors[] = "Campo 2 esta Vacío";
	}else if (!empty($_POST['a_camp1']) && !empty($_POST['a_camp2'])) {
		$campo1 = $_POST['a_camp1'];
		$campo2 = $_POST['a_camp2'];
		$id = intval($_POST['a_id']);
		$save = $mysqli->query("UPDATE data SET fn = '$campo1', ln = '$campo2' WHERE id = '$id'");
		if ($save) {
			$messages[] = "Los Datos fueron Actualizados Exitosamente";
		}else{
			$errors[] = "Ocurrio un Error al momento de Actualizar los Datos";
		}
	}	
	

	if (isset($errors)) {
		?>
		<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<strong>Error!</strong> 
				<?php
				foreach ($errors as $error) {
					echo $error;
				}
				?>
		</div>
		<?php
	}

	if (isset($messages)) {
		?>
		<div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<strong>¡Bien hecho!</strong>
			<?php
			foreach ($messages as $message) {
				echo $message;
			}
			?>
		</div>
		<?php
	}
}
?>