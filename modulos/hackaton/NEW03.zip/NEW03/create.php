<?php
	require_once 'dbconfig.php';
	if($_POST) {
		
		if (empty($_POST['i_camp1'])) {
			$errors[] = "Campo 1 esta Vacío";
		}else if (empty($_POST['i_camp2'])) {
			$errors[] = "Campo 2 esta Vacío";
		}else if (!empty($_POST['i_camp1']) && !empty($_POST['i_camp2'])) {
			$campo1 = $_POST['i_camp1'];
			$campo2 = $_POST['i_camp2'];

			$save = $mysqli->query("INSERT INTO data(fn, ln) VALUES('$campo1','$campo2')");
			if ($save) {
				$messages[] = "Los Datos fueron Guardados Exitosamente";
			}else{
				$errors[] = "Ocurrio un Error al momento de Guardar los Datos";
			}
		}	

		if (isset($errors)) {
		?>
		<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<strong>Error!</strong> 
				<?php
				foreach ($errors as $error) {
					echo $error;
				}
				?>
		</div>
		<?php
	}

	if (isset($messages)) {
		?>
		<div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<strong>¡Bien hecho!</strong>
			<?php
			foreach ($messages as $message) {
				echo $message;
			}
			?>
		</div>
		<?php
	}
	}
?>